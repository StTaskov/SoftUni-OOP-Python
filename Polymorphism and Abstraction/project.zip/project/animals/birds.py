from project.animals.animal import Bird
from project.food import *


class Owl(Bird):

    per_piece = 0.25

    def __init__(self, name, weight, wing_size):
        super().__init__(name, weight, wing_size)
        self.wing_size = wing_size

    def make_sound(self):
        return "Hoot Hoot"

    def feed(self, food):
        if isinstance(food, Meat):
            self.food_eaten += food.quantity
            self.weight += food.quantity * Owl.per_piece
        else:
            return f"{type(self).__name__} does not eat {type(food).__name__}!"


class Hen(Bird):

    per_piece = 0.35

    def __init__(self, name, weight, wing_size):
        super().__init__(name, weight, wing_size)
        self.wing_size = wing_size

    def make_sound(self):
        return "Cluck"

    def feed(self, food):
        self.food_eaten += food.quantity
        self.weight += food.quantity * Hen.per_piece


