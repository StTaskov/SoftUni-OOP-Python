from project.animals.animal import Mammal
from project.food import *


class Mouse(Mammal):

    per_piece = 0.10

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "Squeak"

    def feed(self, food):
        if isinstance(food, Vegetable) or isinstance(food, Fruit):
            self.food_eaten += food.quantity
            self.weight += food.quantity * Mouse.per_piece
        else:
            return f"{type(self).__name__} does not eat {type(food).__name__}!"


class Dog(Mammal):

    per_piece = 0.40

    def __init__(self, name, weight, living_region,):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "Woof!"

    def feed(self, food):
        if isinstance(food, Meat):
            self.food_eaten += food.quantity
            self.weight += food.quantity * Dog.per_piece
        else:
            return f"{type(self).__name__} does not eat {type(food).__name__}!"


class Cat(Mammal):

    per_piece = 0.30

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "Meow"

    def feed(self, food):
        if isinstance(food, Vegetable) or isinstance(food, Meat):
            self.food_eaten += food.quantity
            self.weight += food.quantity * Cat.per_piece
        else:
            return f"{type(self).__name__} does not eat {type(food).__name__}!"


class Tiger(Mammal):

    per_piece = 1

    def __init__(self, name, weight, living_region):
        super().__init__(name, weight, living_region)

    def make_sound(self):
        return "ROAR!!!"

    def feed(self, food):
        if isinstance(food, Meat):
            self.food_eaten += food.quantity
            self.weight += food.quantity * Tiger.per_piece
        else:
            return f"{type(self).__name__} does not eat {type(food).__name__}!"

